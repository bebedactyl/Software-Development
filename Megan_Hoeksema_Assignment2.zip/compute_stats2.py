import sys, csv, statistics

def main():
    """
       Args: None
       Returns: A list of values to be used in other functions."""

    # Handles data coming in, removes all the whitespace
    data = sys.argv[2]
    with open(data, 'r') as f:
        reader = csv.reader(f, delimiter = ' ', skipinitialspace=True)
        included_cols = [int(sys.argv[1]) - 1]

        # converts each element from a string to a float then appends to a list for sorting
        values = []
        for row in reader:
            content = list(row[i] for i in included_cols)
            content = [float(x) for x in content]
            values.append(content)

        # sorts elements from smallest to largest
        values = sorted(values)

    # Removes missing data(indicated in README as -9999.0) from list.
    missingData = [-9999.0]
    if missingData in values:
        values.remove(missingData)

    #flatens list of lists to a list for calculations
    values = [item for elem in values for item in elem]
    return values

def compute_stats(values):
    """Computes the min, max, median and average of a list
       Args: values(list): A list of values generated from main()
       Returns: A tuple of the min, max, avg, and median values"""
    if values is None or len(values) == 0:
        return None

    o_min = min(values)
    o_max =max(values)
    o_avg = statistics.mean(values)
    o_median =statistics.median(values)

    return (o_min, o_max, o_avg, o_median)

if __name__ == "__main__":
    print(compute_stats(main()))