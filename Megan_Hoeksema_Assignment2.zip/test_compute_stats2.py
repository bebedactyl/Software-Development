import unittest
import compute_stats2

class TestComputeStats(unittest.TestCase):

    def test_evenElements(self):
        """Tests a list with an even number of elements"""
        l = compute_stats2.compute_stats([1, 2, 3, 4])
        self.assertEqual(l, (1, 4, 2.5, 2.5))

    def test_oddElements(self):
        """Tests a list with an odd number of elements"""
        l = compute_stats2.compute_stats([1, 2, 3])
        self.assertEqual(l, (1, 3, 2, 2))

    def test_emptyList(self):
        """Tests an empty list"""
        l = compute_stats2.compute_stats(list())
        self.assertIsNone(l)

    def test_singleElementList(self):
        """Tests a list containing a single element"""
        l = compute_stats2.compute_stats([1])
        self.assertEqual(l, (1, 1, 1, 1))

if __name__ == '__main__':
    unittest.main()