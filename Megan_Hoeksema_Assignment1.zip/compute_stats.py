import sys
import statistics

# Handles data coming in, converts to a list of floats for calculations.
l = []
for line in sys.stdin:
    l.append(line.strip())
    l = [(float(i)) for i in l]

# Removes missing data(indicated in README as -9999.0) from list(l).
missingData = -9999.0
if missingData in l:
     l.remove(missingData)

# Calculates the average, minimum, maximum and median.
aveVal = statistics.mean(l)
minVal = min(l)
maxVal = max(l)
medVal = statistics.median(l)

# Prints results.
print('min:', minVal, 'max:', maxVal, 'average:', aveVal, 'median:', medVal)


