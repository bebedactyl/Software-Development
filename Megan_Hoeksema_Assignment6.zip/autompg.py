import csv, os

class AutoMPG:
    """"""

    def __init__(self, make, model, year, mpg):
        """Constructor that takes four parameters after self and initializes the attributes.
           Args:
           make: A string. Automobile manufacturer. First token in the “car name” field of the data set.
           model: A string. Automobile model. All other tokens in the “car name” field of the data set except the first.
           year: An integer. Four-digit year that corresponds to the “model year” field of the data set.
           mpg: A float. Correspond to miles per gallon"""
        self.make = str(make)
        self.model = str(model)
        self.year = 1900 + year
        self.mpg = mpg

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return ('AutoMPG(make = %d,  model= %d, year = %d, mpg = %d )' % (self.make, self.model, self.year, self.mpg))


    def __str__(self):
        """Returns a shorthand representation of the object"""
        return ('AutoMPG(make = %d,  model= %d, year = %d, mpg = %d )' % (self.make, self.model, self.year, self.mpg))

    def __eq__(self, other):
        """Defines equality logic"""
        if type(self) == type(other):
            return self.make == other.make and self.model == other.model and self.year == other.year and self.mpg == other.mpg
        else:
            return NotImplemented

    def __lt__(self, other):
        """Defines less than logic"""
        if type(self) == type(other):
            return (self.make, self.model, self.year, self.mpg) < (other.make, other.model, other.year, other.mpg)
        else:
            return NotImplemented

    def __hash__(self):
        """"""
        return hash((self.make and self.model and self.year and self.mpg))

class AutoMPGData:
    """"""

    def __init__(self):
        """Constructor, calls the load_data method."""
        data = self._load_data

    def __iter__(self):
        """Makes the class iterable. Returns and iterator over the data"""
        return self

    def _load_data(self):
        """Loads clean data. Calls _clean_data if clean data does not exist"""
        path = '/home/User/Desktop/auto-mpg.clean.txt'
        isExist = os.path.exists(path)
        if isExist == True:
            with open('auto-mpg.clean.txt') as f:
                reader = csv.reader(f, delimiter=' ')
        else:
            data = self._load_data()


    def _clean_data(self):
        """Reads original data file line by line"""

        with open('auto-mpg.data.txt', 'r') as f:
            content = f.readlines()
            content = [x.strip() for x in content]
            content = [x.expandtabs() for x in content]
            print(content)

            with open("auto-mpg.clean.txt", "w") as f:
                writer = csv.writer(f)
                for row in content:
                    writer.writerow(row)

def main():
    for auto in AutoMPGData:
        print(auto)

if __name__ == "__main__":
    main()