import random, sys, csv
from collections import namedtuple
from collections import defaultdict

Score = namedtuple('Score', 'total, soft_ace_count')
Stand = namedtuple('Stand', 'stand, total')


class Hand:
    """Class that encapsulates a hand a blackjack"""

    def __init__(self, cards=None):
        """This is the class constructor."""
        self.cards = []
        self.total, self.soft_ace_count = self.score()

    def __str__(self):
        """Returns a string representing a hand"""
        return str(self.cards)

    def add_card(self):
        """Adds another card to the hand"""
        self.cards.append(random.randint(1, 13))
        self.score()

    def is_blackjack(self):
        """Returns True if hand is represents a blackjack (i.e. a soft ace + either a K, Q, J or 10."""
        if self.total == 21 and self.soft_ace_count == 1:
            if 10 in self.cards or 11 in self.cards or 12 in self.cards or 13 in self.cards:
                return True
        else:
            return False

    def is_bust(self):
        """Returns True if the hand is greater than 21"""
        if self.total > 21:
            return True
        else:
            return False

    def score(self):
        """Computes the score for the hand. Returns the hand total and the number of soft aces"""
        self.total = 0
        self.soft_ace_count = 0

        for card in self.cards:
            if card >= 10:
                self.total += 10
            elif card == 1:
                if self.total >= 11:
                    self.total += 1
                else:
                    self.total += 11
                    self.soft_ace_count += 1
            else:
                self.total += card
        return (self.total, self.soft_ace_count)


class Strategy:
    """"""

    def __init__(self, stand_on_value, stand_on_soft):
        """This is a class constructor"""
        self.stand_on_value = stand_on_value
        self.stand_on_soft = stand_on_soft

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return ("Strategy(stand_on_value = %d, stand_on_soft = %d)" % (self.stand_on_value, self.stand_on_soft))

    def __str__(self):
        """Returns a shorthand representation of the object"""
        if self.stand_on_soft == True:
            return "Strategy: S%d" % (self.stand_on_value)
        if self.stand_on_soft == False:
            return "Strategy: H%d" % (self.stand_on_value)

    def stand(self, hand):
        """Determines if the strategy requires a Hit(returns False) or a Stand(returns True)"""

        total, soft_ace_count = hand.score()

        if total < self.stand_on_value:
            return False
        elif total >= self.stand_on_value:
            return True
        elif soft_ace_count == 0 or self.stand_on_soft:
            return True
        else:
            return False

    def play(self):
        """Plays a single hand of blackjack"""

        hand = Hand()

        hand.add_card(), hand.add_card()

        self.stand(hand)

        while self.stand(hand) == False:
            hand.add_card()

        return hand


USAGE = f'usage: {sys.argv[0]} <num-simulations>'


def main():
    """Runs a number of simulations that loops across all stand on values from 13-20 and both stand on soft and
    stand on hard. Returns: A table corresponding to the percent of simulations for certain criteria."""
    assert len(sys.argv) == 2, USAGE
    n = int(sys.argv[1])
    assert n > 0, USAGE

    writer = csv.writer(sys.stdout, quoting=csv.QUOTE_ALL)
    writer.writerow(['P-Strategy', 'D-H13', 'D-S13', 'D-H14', 'D-S14', 'D-H15', 'D-S15', 'D-H16', 'D-S16',
                     'D-H17', 'D-S17', 'D-H18', 'D-S18', 'D-H19', 'D-S19', 'D-H20', 'D-S20'])

    #Dealer Hand
    for stand_on_value in range(13, 21):
        for stand_on_soft in ((False, 'P-H'), (True, 'P-S')):
            totalDealer = defaultdict(int)
            for i in range(n):
                total = Strategy(stand_on_value, stand_on_soft)
                totalDealer[total] += 1

    #Player Hand
    for stand_on_value in range(13, 21):
        for stand_on_soft in ((False, 'P-H'), (True, 'P-S')):
            totalPlayer = defaultdict(int)
            for i in range(n):
                total = Strategy(stand_on_value, stand_on_soft)
                if total != totalDealer:
                    totalPlayer[total] += 1

            strat = f'{stand_on_soft[1]}{stand_on_value}'
            row = [strat]
            for i in range(13, 21):
                percentage = f'{100 * totalPlayer[i]- totalDealer[i] / n:.2f}'
                row.append(percentage)
            writer.writerow(row)


if __name__ == '__main__':
    main()

# hand = Hand()
# hand.add_card()
# hand.add_card()
# print(hand)
# print(hand.score())
# print(hand.is_bust())
# print(hand.is_blackjack())
#
# x = Strategy(stand_on_value=12, stand_on_soft=True)
# print(repr(x))
# print(str(x))
# print(x.stand(hand))

# hand = Strategy(stand_on_value=17, stand_on_soft=True)
# print(hand.play())

# hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
# hand = Hand()
# hand.cards = [5, 7, 2, 2]
#
# print(hand)
# print(hand.score())
# print(hand2.stand(hand))
