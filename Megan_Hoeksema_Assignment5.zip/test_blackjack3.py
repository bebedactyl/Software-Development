"""Unit tests for the blackjack3 program."""
import unittest

from blackjack3 import *

class TestBlackjack(unittest.TestCase):

    def test_score_basic(self):

        hand = Hand()
        hand.cards = []
        self.assertEqual((0, 0), hand.score())

        hand = Hand()
        hand.cards = [3]
        self.assertEqual((3, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [3, 2]
        self.assertEqual((5, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [3, 2, 10]
        self.assertEqual((15, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())


        # 11 counts as 10
        hand = Hand()
        hand.cards = [3, 2, 10, 11]
        self.assertEqual((25, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertTrue(hand.is_bust())

        # 12 counts as 10
        hand = Hand()
        hand.cards = [3, 2, 10, 11, 12]
        self.assertEqual((35, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertTrue(hand.is_bust())

        # 13 counts as 10
        hand = Hand()
        hand.cards = [3, 2, 10, 11, 12, 13]
        self.assertEqual((45, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertTrue(hand.is_bust())

    def test_score_from_assignment(self):
        hand = Hand()
        hand.cards = [3,12 ]
        self.assertEqual((13, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [5, 5, 10]
        self.assertEqual((20, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [11, 10, 1]
        self.assertEqual((21, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 5]
        self.assertEqual((16, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 1, 5]
        self.assertEqual((17, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 1, 1, 7]
        self.assertEqual((20, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [7, 8, 10]
        self.assertEqual((25, 0), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertTrue(hand.is_bust())

    def test_score_with_soft_aces(self):
        hand = Hand()
        hand.cards = [1]
        self.assertEqual((11, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 10]
        self.assertEqual((21, 1), hand.score())
        self.assertTrue(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 2, 3]
        self.assertEqual((16, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        hand = Hand()
        hand.cards = [1, 2, 3, 1]
        self.assertEqual((17, 1), hand.score())
        self.assertFalse(hand.is_blackjack())
        self.assertFalse(hand.is_bust())

        # hand = Hand()
        # hand.cards = [1, 2, 3, 10]
        # self.assertEqual((16, 0), hand.score())
        # self.assertFalse(hand.is_blackjack())
        # self.assertFalse(hand.is_bust())

        # hand = Hand()
        # hand.cards = [1, 2, 3, 10, 1]
        # self.assertEqual((17, 0), hand.score())
        # self.assertFalse(hand.is_blackjack())
        # self.assertFalse(hand.is_bust())

    def test_is_Blackjack(self):

        hand = Hand()
        hand.cards = [1, 10]
        self.assertEqual((21, 1), hand.score())
        self.assertTrue(hand.is_blackjack())

        hand = Hand()
        hand.cards = [1, 11]
        self.assertEqual((21, 1), hand.score())
        self.assertTrue(hand.is_blackjack())

        hand = Hand()
        hand.cards = [1, 12]
        self.assertEqual((21, 1), hand.score())
        self.assertTrue(hand.is_blackjack())

        hand = Hand()
        hand.cards = [1, 13]
        self.assertEqual((21, 1), hand.score())
        self.assertTrue(hand.is_blackjack())

    def test_is_hit(self):

        # 1.) Cards input are below stand value
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 8]
        self.assertEqual(False, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        hand = Hand()
        hand.cards = [5, 8]
        self.assertEqual(False, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 7, 3]
        self.assertEqual(False, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        hand = Hand()
        hand.cards = [5, 7, 3]
        self.assertEqual(False, hand2.stand(hand))

        # 2.) Cards input are at stand value but no aces
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 7, 2, 2]
        self.assertEqual(True, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 7, 2, 2]
        self.assertEqual(True, hand2.stand(hand))

        # 3.) Cards input are at stand value, contain an ace, and hand is hard
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 5, 5, 1]
        self.assertEqual(True, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        hand = Hand()
        hand.cards = [5, 5, 5, 1]
        self.assertEqual(True, hand2.stand(hand))

        # 4.) Cards input are at stand value and hand is soft
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 1]
        self.assertEqual(True, hand2.stand(hand))

        # hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        # hand = Hand()
        # hand.cards = [5, 1]
        # self.assertEqual(False, hand2.stand(hand))

        # 5.) Cards input are above stand value, contain no aces
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [5, 5, 3, 4]
        self.assertEqual(True, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        hand = Hand()
        hand.cards = [5, 5, 3, 4]
        self.assertEqual(True, hand2.stand(hand))

        # 6.) Card above stand value, contain an ace
        hand2 = Strategy(stand_on_value=16, stand_on_soft=True)
        hand = Hand()
        hand.cards = [3, 3, 1]
        self.assertEqual(True, hand2.stand(hand))

        hand2 = Strategy(stand_on_value=16, stand_on_soft=False)
        hand = Hand()
        hand.cards = [3, 3, 1]
        self.assertEqual(True, hand2.stand(hand))


if __name__ == '__main__':
    unittest.main()
