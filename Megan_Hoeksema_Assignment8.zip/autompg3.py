import csv, os.path, sys
import logging, argparse, requests, statistics
from collections import namedtuple
from collections import defaultdict
import matplotlib.pyplot as plt

class AutoMPG:
    """"""

    def __init__(self, make, model, year, mpg):
        """Constructor that takes four parameters after self and initializes the attributes.
           Args:
           make: A string. Automobile manufacturer. First token in the “car name” field of the data set.
           model: A string. Automobile model. All other tokens in the “car name” field of the data set except the first.
           year: An integer. Four-digit year that corresponds to the “model year” field of the data set.
           mpg: A float. Correspond to miles per gallon"""
        self.make = str(make)
        self.model = str(model)
        self.year = 1900 + int(year)
        self.mpg = float(mpg)

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return f"AutoMPG('{self.make}', '{self.model}', {self.year}, {self.mpg})"

    def __str__(self):
        """Returns a shorthand representation of the object"""
        return f"AutoMPG('{self.make}', '{self.model}', {self.year}, {self.mpg})"

    def __eq__(self, other):
        """Defines equality logic"""
        if type(self) == type(other):
            return (self.make, self.model, self.year, self.mpg) == (other.make, other.model, other.year, other.mpg)
        else:
            return NotImplemented

    def __lt__(self, other):
        """Defines less than logic"""
        if type(self) == type(other):
            return (self.make, self.model, self.year, self.mpg) < (other.make, other.model, other.year, other.mpg)
        else:
            return NotImplemented

    def __hash__(self):
        """"""
        return hash((self.make and self.model and self.year and self.mpg))


class AutoMPGData:
    """"""
    DATA_FILE_ORIG = 'auto-mpg.data.txt'
    DATA_FILE_CLEAN = 'auto-mpg.clean.txt'

    def __init__(self):
        """Constructor, calls the load_data method."""
        self._load_data()

    def __iter__(self):
        """Makes the class iterable. Returns an iterator over the data"""
        return iter(self.data)

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return "AutoMPGData()"

    def __str__(self):
        """Returns a shorthand representation of the object"""
        return str(self.data)

    def _load_data(self):
        """Loads clean data. Calls _clean_data if clean data does not exist
           Calls _get_data if original data does not exist."""

        logging.info('Checking auto-mpg.data.txt')
        if not os.path.exists(AutoMPGData.DATA_FILE_ORIG):
            logging.info('getting auto-mpg.data.txt')
            self._get_data()
        else:
            logging.debug('auto-mpg.data.txt exists')

        if not os.path.exists(AutoMPGData.DATA_FILE_CLEAN):
            logging.info('Checking auto-mpg.clean.txt')
            self._clean_data()
        else:
            logging.info('auto-mpg.clean.txt exists')

        Record = namedtuple('Record', 'mpg, cylinders, displacement, horsepower, weight, acceleration, model_year, '
                                      'origin, car_name')

        self.data = []
        with open(AutoMPGData.DATA_FILE_CLEAN, 'r') as f:
            reader = csv.reader(f, delimiter=' ', skipinitialspace=True)
            for row in reader:
                rec = Record(*[tok.strip() for tok in row])
                name_parts = rec.car_name.split()
                auto = AutoMPG(name_parts[0], " ".join(name_parts[1:]), rec.model_year, rec.mpg)
                self.data.append(auto)

    def _clean_data(self):
        """Reads original data file line by line"""

        ifname = AutoMPGData.DATA_FILE_ORIG
        ofname = AutoMPGData.DATA_FILE_CLEAN
        with open(ifname, 'r') as ifile:
            with open(ofname, 'w') as ofile:
                for line in ifile:
                    if 'chevy' in line:
                        line = line.replace('chevy', 'chevrolet')
                        ofile.write(line.expandtabs())
                    elif 'chevroelt' in line:
                        line = line.replace('chevroelt', 'chevrolet')
                        ofile.write(line.expandtabs())
                    elif 'maxda' in line:
                        line = line.replace('maxda', 'mazda')
                        ofile.write(line.expandtabs())
                    elif 'mercedes-benz' in line:
                        line = line.replace('mercedes-benz', 'mercedes')
                        ofile.write(line.expandtabs())
                    elif 'toyouta' in line:
                        line = line.replace('toyouta', 'toyota')
                        ofile.write(line.expandtabs())
                    elif 'vokswagen' in line:
                        line = line.replace('vokswagen', 'volkswagen')
                        ofile.write(line.expandtabs())
                    elif 'vw' in line:
                        line = line.replace('vw', 'volkswagen')
                        ofile.write(line.expandtabs())
                    else:
                        ofile.write(line.expandtabs())

    def sort_by_default(self):
        """Sorts the data list in place. The list will be sorted by make, model, year, and then mpg"""
        self.data.sort()
        logging.info('sorting AutoMPG objects by default')

    def sort_by_year(self):
        """The sorting happens by year, make, model, mpg"""
        self.data.sort(key=lambda x: (x.year, x.make, x.model, x.mpg))
        logging.info('sorting AutoMPG objects by year')

    def sort_by_mpg(self):
        """The sorting happens by mpg, make, model, year"""
        self.data.sort(key=lambda x: (x.mpg, x.make, x.model, x.year))
        logging.info('sorting AutoMPG objects by mpg')

    def _get_data(self):
        """Downloads the original data file from the UCI Machine Learning Repository and saves it in the local file as
           auto-mpg.data.txt."""

        r = requests.get('https://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data')
        self.response_code = r.status_code
        logging.info('Getting auto-mpg.data.txt')
        logging.debug(f'response code from url: {self.response_code}')
        local_file = 'auto-mpg.data.txt'
        with open(local_file, 'wb') as file:
            file.write(r.content)

    def mpg_by_year(self):
        """Returns a dictionary where keys == year and values == average mpg for that year"""
        yearDict = defaultdict(list)
        for object in self.data:
            yearDict[object.year].append(object.mpg)
        aveYearDict = {}
        for year, mpg in yearDict.items():
            aveYearDict[year] = statistics.mean(mpg)
        return aveYearDict
        # for year, mpg in aveYearDict.items():
        #     print(year, mpg)

    def mpg_by_make(self):
        """Returns a dictionary where keys == make and values == average mpg for that year"""
        makeDict = defaultdict(list)
        for object in self.data:
            makeDict[object.make].append(object.mpg)
        aveMakeDict = {}
        for make, mpg in makeDict.items():
            aveMakeDict[make] = statistics.mean(mpg)
        return aveMakeDict

def main():
    # Get the root logger, set default to DEBUG
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # File Handler
    fh = logging.FileHandler('autompg2.log', 'w')
    fh.setLevel(logging.DEBUG)
    logger.addHandler(fh)

    # Stream Handler
    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    logger.addHandler(sh)

    # Application Code
    logging.debug('very detailed information')
    logging.info('tracing info')
    logging.warning('something bad might happen')
    logging.error('something bad happened')
    logging.critical('something really bad happened')

    logging.info("parsing auto-mpg.clean.txt into AutoMPG objects")
    # Command Line Parsing
    parser = argparse.ArgumentParser(description='Parse data from specified access_log')

    # Required Argument
    parser.add_argument('command', metavar='<command>', type=str, help='Command to execute', choices=['print',
                                                                                                      'mpg_by_year',
                                                                                                      'mpg_by_make'])

    # Optional Arguments
    parser.add_argument('-s', '--sort', metavar='<sort order>', type=str, dest='sort',
                        help='sort order by year, mpg or default', default='default', choices=['year', 'mpg', 'default'])
    parser.add_argument('-o', '--ofile', metavar='<out_file>', type=str, dest='ofile',
                        help='filename of a file to which output should be written', default='sys.stdout')
    parser.add_argument('-p', '--plot', metavar='<plot>', type=str, dest='plot',
                        help='graphical output using matplotlib')

    run(parser.parse_args())

def run(args):
    dataset = AutoMPGData()

    if args.sort == "year":
        dataset.sort_by_year()
        logging.debug("sorting autoMPG objects by year")

    elif args.sort == "mpg":
        dataset.sort_by_mpg()
        logging.debug("sorting autoMPG objects by mpg")

    else:
        dataset.sort_by_default()
        logging.debug("sorting autoMPG objects by default")

    if args.command == 'print':
        for d in dataset:
            logging.info(d)

    elif args.command == 'mpg_by_make':
        data = dataset.mpg_by_make()
        print('Make,', 'MPG')
        for k, v in data.items():
            print(f'{k}, {v}')

        if args.ofile == 'filename':
            csv_columns = ['make', 'mpg']
            with open('filename', 'w') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()
                for i in data:
                    writer.writerow(i)

        if args.command == '-p':
            x = data.keys()
            y = data.values()
            plt.plot(x, y, 'r--')
            plt.show()

    elif args.command == 'mpg_by_year':
        data = dataset.mpg_by_year()
        print('Year,', 'MPG')
        for k, v in data.items():
            print(f'{k}, {v}')

        if args.ofile == 'filename':
            csv_columns = ['make', 'mpg']
            with open('filename', 'w') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()
                for i in data:
                    writer.writerow(i)

        if args.command == '-p':
            x = data.keys()
            y = data.values()
            plt.plot(x, y, 'r--')
            plt.show()

if __name__ == "__main__":
    main()
