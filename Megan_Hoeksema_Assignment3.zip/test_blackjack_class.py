"""Unit tests for the blackjack program."""
import unittest

import blackjack

class TestBlackjack(unittest.TestCase):

    def test_score_basic(self):
        ret = blackjack.score([3])
        self.assertEqual((3, 0), ret)

        ret = blackjack.score([3, 2])
        self.assertEqual((5, 0), ret)

        ret = blackjack.score([3, 2, 10])
        self.assertEqual((15, 0), ret)

        # 11 counts as 10
        ret = blackjack.score([3, 2, 10, 11])
        self.assertEqual((25, 0), ret)

        # 12 counts as 10
        ret = blackjack.score([3, 2, 10, 11, 12])
        self.assertEqual((35, 0), ret)

        # 13 counts as 10
        ret = blackjack.score([3, 2, 10, 11, 12, 13])
        self.assertEqual((45, 0), ret)

    def test_score_from_assignment(self):
        self.assertEqual(blackjack.score([ 3, 12 ]), (13, 0))
        self.assertEqual(blackjack.score([ 5, 5, 10 ]), (20, 0))
        self.assertEqual(blackjack.score([ 11, 10, 1 ]), (21, 0))
        self.assertEqual(blackjack.score([ 1, 5 ]), (16, 1))
        self.assertEqual(blackjack.score([ 1, 1, 5 ]), (17, 1))
        self.assertEqual(blackjack.score([ 1, 1, 1, 7 ]), (20, 1))
        self.assertEqual(blackjack.score([ 7, 8, 10 ]), (25, 0))

    def test_score_with_soft_aces(self):
        ret = blackjack.score([1])
        self.assertEqual((11, 1), ret)

        ret = blackjack.score([1,10])
        self.assertEqual((21, 1), ret)

        ret = blackjack.score([1, 2, 3])
        self.assertEqual((16, 1), ret)

        ret = blackjack.score([1, 2, 3, 1])
        self.assertEqual((17, 1), ret)

        # ret = blackjack.score([1, 2, 3, 10])
        # self.assertEqual((16, 0), ret)
        #
        # ret = blackjack.score([1, 2, 3, 10, 1])
        # self.assertEqual((17, 0), ret)

    def test_is_hit(self):
        STAND_ON_SOFT = True
        HIT_ON_SOFT = False

        # 1.) Cards input are below stand value
        self.assertFalse(blackjack.stand(16, STAND_ON_SOFT, [5, 8]))
        self.assertFalse(blackjack.stand(16, HIT_ON_SOFT, [5, 8]))
        self.assertFalse(blackjack.stand(16, STAND_ON_SOFT, [5, 7, 3]))
        self.assertFalse(blackjack.stand(16, HIT_ON_SOFT, [5, 7, 3]))

        # 2.) Cards input are at stand value but no aces
        self.assertTrue(blackjack.stand(16, STAND_ON_SOFT, [5, 7, 2, 2]))
        self.assertTrue(blackjack.stand(16, HIT_ON_SOFT, [5, 7, 2, 2]))

        # 3.) Cards input are at stand value, contain an ace, and hand is hard
        self.assertTrue(blackjack.stand(16, STAND_ON_SOFT, [5, 5, 5, 1]))
        self.assertTrue(blackjack.stand(16, HIT_ON_SOFT, [5, 5, 5, 1]))

        # 4.) Cards input are at stand value and hand is soft
        self.assertTrue(blackjack.stand(16, STAND_ON_SOFT, [5, 1]))
        self.assertFalse(blackjack.stand(16, HIT_ON_SOFT, [5, 1]))

        # 5.) Cards input are above stand value, contain no aces
        self.assertTrue(blackjack.stand(16, STAND_ON_SOFT, [5, 5, 3, 4]))
        self.assertTrue(blackjack.stand(16, HIT_ON_SOFT, [5, 5, 3, 4]))

        # 6.) Card above stand value, contain an ace
        self.assertTrue(blackjack.stand(16, STAND_ON_SOFT, [3, 3, 1]))
        self.assertFalse(blackjack.stand(16, HIT_ON_SOFT, [3, 3, 1]))
        
if __name__ == '__main__':
    unittest.main()

