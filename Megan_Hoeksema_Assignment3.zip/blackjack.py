import random, sys

def get_card():
    """Function to deal a card. Note: 1 = ace, 2–10 number cards, {11,12,13} are jack, queen, king.
       Args: None
       Returns a random number between 1 and 13 indicating a card."""

    cards = random.randint(1, 13)
    return cards

def score(cards):
    """Calculates the score based on the cards in the hand.
       Args: cards (list): a list of integers representing the cards of a blackjack hand
       Returns: A tuple where the first value is the total value of the hand and the second is the number of soft
       aces (aces counted as an 11) that remain in the hand."""

    total = 0
    soft_ace_count = 0

    for card in cards:
        if card >= 10:
            total += 10
        elif card == 1:
            if total >= 11:
                total += 1
            else:
                total += 11
                soft_ace_count += 1
        else:
            total += card

    return (total, soft_ace_count)

def stand(stand_on_value, stand_on_soft, cards):
    """Determines, based on hand value, whether to stand or hit.
       Args: stand_on_value: an integer 1-20, determining the value at which to stand
             stand_on_soft (bool): True for stand, False for hit.
             cards: returned from get_card() function
       Returns: True for a stand and False for a hit."""

    total, soft_ace_count = score(cards)

    if total < stand_on_value:
        return False

    if total >= stand_on_value:
        # For 'soft' ace
        if soft_ace_count >= 1:
            if stand_on_soft == True:
                return True
            if stand_on_soft == False:
                return False

        # For 'hard' ace
        if soft_ace_count == 0:
            return True

def main():
    """Computes the bust percentage within a given number of simulations, under certain play strategies.
       Args: Takes in 3 arguments from the command line.
             num_simulations: an integer indicating the number of hands to simulate.
             stand_on_value: an integer between 1 and 20.
             stand_on_soft: a string, either 'soft' or 'hard' based on the strategy to employ.
       Returns: the percentage of hands that busted within the given simulation."""

    assert len(sys.argv) in (3,4)

    try:
        num_simulations = int(sys.argv[1])
        stand_on_value = int(sys.argv[2])
        stand_on_soft = sys.argv[3]
        if stand_on_soft == 'soft':
            stand_on_soft = True
        elif stand_on_soft == 'false':
            stand_on_soft = False
    except ValueError:
        print('Incorrect input detected. Please try again.')

    bust = 0
    for i in range(num_simulations):
        cards = [get_card(), get_card()]
        while True:
            if stand(stand_on_value, stand_on_soft, cards) is False:
                cards.append(get_card())
                continue
            elif score(cards)[0] > 21:
                bust += 1
                break
            else:
                break
    return bust * 100 / num_simulations

if __name__ == "__main__":
    print(main())


