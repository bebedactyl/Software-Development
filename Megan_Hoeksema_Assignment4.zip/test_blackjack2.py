"""Unit tests for the blackjack2 program."""
import unittest

import blackjack2

class TestBlackjack(unittest.TestCase):

    def test_score_basic(self):
        ret = blackjack2.score([3])
        self.assertEqual((3, 0), ret)

        ret = blackjack2.score([3, 2])
        self.assertEqual((5, 0), ret)

        ret = blackjack2.score([3, 2, 10])
        self.assertEqual((15, 0), ret)

        # 11 counts as 10
        ret = blackjack2.score([3, 2, 10, 11])
        self.assertEqual((25, 0), ret)

        # 12 counts as 10
        ret = blackjack2.score([3, 2, 10, 11, 12])
        self.assertEqual((35, 0), ret)

        # 13 counts as 10
        ret = blackjack2.score([3, 2, 10, 11, 12, 13])
        self.assertEqual((45, 0), ret)

    def test_score_from_assignment(self):
        self.assertEqual(blackjack2.score([ 3, 12 ]), (13, 0))
        self.assertEqual(blackjack2.score([ 5, 5, 10 ]), (20, 0))
        self.assertEqual(blackjack2.score([ 11, 10, 1 ]), (21, 0))
        self.assertEqual(blackjack2.score([ 1, 5 ]), (16, 1))
        self.assertEqual(blackjack2.score([ 1, 1, 5 ]), (17, 1))
        self.assertEqual(blackjack2.score([ 1, 1, 1, 7 ]), (20, 1))
        self.assertEqual(blackjack2.score([ 7, 8, 10 ]), (25, 0))

    def test_score_with_soft_aces(self):
        ret = blackjack2.score([1])
        self.assertEqual((11, 1), ret)

        ret = blackjack2.score([1,10])
        self.assertEqual((21, 1), ret)

        ret = blackjack2.score([1, 2, 3])
        self.assertEqual((16, 1), ret)

        ret = blackjack2.score([1, 2, 3, 1])
        self.assertEqual((17, 1), ret)

        # ret = blackjack2.score([1, 2, 3, 10])
        # self.assertEqual((16, 0), ret)
        #
        # ret = blackjack2.score([1, 2, 3, 10, 1])
        # self.assertEqual((17, 0), ret)

    def test_is_hit(self):
        STAND_ON_SOFT = True
        HIT_ON_SOFT = False

        # 1.) Cards input are below stand value
        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 8])
        self.assertEqual((False, 13), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 8])
        self.assertEqual((False, 13), ret)

        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 7, 3])
        self.assertEqual((False, 15), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 7, 3])
        self.assertEqual((False, 15), ret)

        # 2.) Cards input are at stand value but no aces
        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 7, 2, 2])
        self.assertEqual((True, 16), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 7, 2, 2])
        self.assertEqual((True, 16), ret)

        # 3.) Cards input are at stand value, contain an ace, and hand is hard
        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 5, 5, 1])
        self.assertEqual((True, 16), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 5, 5, 1])
        self.assertEqual((True, 16), ret)

        # 4.) Cards input are at stand value and hand is soft
        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 1])
        self.assertEqual((True, 16), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 1])
        self.assertEqual((False, 16), ret)

        # 5.) Cards input are above stand value, contain no aces
        ret = blackjack2.stand(16, STAND_ON_SOFT, [5, 5, 3, 4])
        self.assertEqual((True, 17), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [5, 5, 3, 4])
        self.assertEqual((True, 17), ret)

        # 6.) Card above stand value, contain an ace
        ret = blackjack2.stand(16, STAND_ON_SOFT, [3, 3, 1])
        self.assertEqual((True, 17), ret)

        ret = blackjack2.stand(16, HIT_ON_SOFT, [3, 3, 1])
        self.assertEqual((True, 17), ret)
        
if __name__ == '__main__':
    unittest.main()

