import random, sys, csv
from collections import namedtuple
from collections import defaultdict

Score = namedtuple('Score', 'total, soft_ace_count')
Stand = namedtuple('Stand', 'stand, total')

def get_card():
    """Function to deal a card. Note: 1 = ace, 2–10 number cards, {11,12,13} are jack, queen, king.
       Args: None
       Returns a random number between 1 and 13 indicating a card."""

    cards = random.randint(1, 13)
    return cards

def score(cards):
    """Calculates the score based on the cards in the hand.
       Args: cards (list): a list of integers representing the cards of a blackjack hand
       Returns: A namedtuple where the first value is the total value of the hand and the second is the number of soft
       aces (aces counted as an 11) that remain in the hand."""

    total = 0
    soft_ace_count = 0

    for card in cards:
        if card >= 10:
            total += 10
        elif card == 1:
            if total >= 11:
                total += 1
            else:
                total += 11
                soft_ace_count += 1
        else:
            total += card

    score = Score(total, soft_ace_count)

    return score

def stand(stand_on_value, stand_on_soft, cards):
    """Determines, based on hand value, whether to stand or hit.
       Args: stand_on_value: an integer 1-20, determining the value at which to stand
             stand_on_soft (bool): True for stand, False for hit.
             cards: returned from get_card() function
       Returns: True for a stand and False for a hit."""

    total, soft_ace_count = score(cards)

    # if less than stand on value, always hit.
    if total < stand_on_value:
        stand = False

    # if greater than stand on value, always stand.
    elif total > stand_on_value:
        stand = True

    elif soft_ace_count == 0 or stand_on_soft:
        stand = True

    else:
        stand = False

    y = Stand(stand, total)

    return y

def play_hand(stand_on_value, stand_on_soft):
    """"""

    cards = [get_card(), get_card()]

    stand(stand_on_value, stand_on_soft, cards)

    while Stand.stand is False:
        cards.append(get_card())

    total, soft_ace_count = score(cards)

    if total > 21:
        total = 22

    return total

def main():
    """Runs a number of simulations that loops across all stand on values from 13-20 and both stand on soft and
    stand on hard.
       Returns: A table corresponding to the percent of simulations for certain criteria."""

    assert len(sys.argv) == 2

    num_simulations = int(sys.argv[1])
    assert num_simulations > 0

    writer = csv.writer(sys.stdout, quoting=csv.QUOTE_ALL)
    writer.writerow(['Strategy', '13', '14', '15', '16', '17', '18', '19', '20', '21', 'BUST'])

    simulations = defaultdict(int)


    for n in range(num_simulations):
        s = play_hand(stand_on_value=13, stand_on_soft=False)
        if s in simulations:
            simulations[value] += 1

    writer.writerow(['H13', simulations])
    writer.writerow(['S13'])
    writer.writerow(['H14'])
    writer.writerow(['S14'])
    writer.writerow(['H15'])
    writer.writerow(['S15'])
    writer.writerow(['H16'])
    writer.writerow(['S16'])
    writer.writerow(['H17'])
    writer.writerow(['S17'])
    writer.writerow(['H18'])
    writer.writerow(['S18'])
    writer.writerow(['H19'])
    writer.writerow(['S19'])
    writer.writerow(['H20'])
    writer.writerow(['S20'])

if __name__ == "__main__":
    main()


