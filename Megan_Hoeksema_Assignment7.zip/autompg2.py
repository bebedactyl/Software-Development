import csv, os.path, sys
import logging, argparse, requests
from collections import namedtuple

class AutoMPG:
    """"""

    def __init__(self, make, model, year, mpg):
        """Constructor that takes four parameters after self and initializes the attributes.
           Args:
           make: A string. Automobile manufacturer. First token in the “car name” field of the data set.
           model: A string. Automobile model. All other tokens in the “car name” field of the data set except the first.
           year: An integer. Four-digit year that corresponds to the “model year” field of the data set.
           mpg: A float. Correspond to miles per gallon"""
        self.make = str(make)
        self.model = str(model)
        self.year = 1900 + int(year)
        self.mpg = float(mpg)

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return f"AutoMPG('{self.make}', '{self.model}', {self.year}, {self.mpg})"

    def __str__(self):
        """Returns a shorthand representation of the object"""
        return f"AutoMPG('{self.make}', '{self.model}', {self.year}, {self.mpg})"

    def __eq__(self, other):
        """Defines equality logic"""
        if type(self) == type(other):
            return (self.make, self.model, self.year, self.mpg) == (other.make, other.model, other.year, other.mpg)
        else:
            return NotImplemented

    def __lt__(self, other):
        """Defines less than logic"""
        if type(self) == type(other):
            return (self.make, self.model, self.year, self.mpg) < (other.make, other.model, other.year, other.mpg)
        else:
            return NotImplemented

    def __hash__(self):
        """"""
        return hash((self.make and self.model and self.year and self.mpg))


class AutoMPGData:
    """"""
    DATA_FILE_ORIG = 'auto-mpg.data.txt'
    DATA_FILE_CLEAN = 'auto-mpg.clean.txt'

    def __init__(self):
        """Constructor, calls the load_data method."""
        self._load_data()

    def __iter__(self):
        """Makes the class iterable. Returns an iterator over the data"""
        return iter(self.data)

    def __repr__(self):
        """Returns canonical string representation of the object"""
        return "AutoMPGData()"

    def __str__(self):
        """Returns a shorthand representation of the object"""
        return str(self.data)

    def _load_data(self):
        """Loads clean data. Calls _clean_data if clean data does not exist
           Calls _get_data if original dat does not exist."""

        logging.info('Checking auto-mpg.data.txt')
        if not os.path.exists(AutoMPGData.DATA_FILE_ORIG):
            self._get_data()
            logging.info('getting auto-mpg.data.txt')

        logging.info('Checking auto-mpg.clean.txt')
        if not os.path.exists(AutoMPGData.DATA_FILE_CLEAN):
            self._clean_data()

        if os.path.exists(AutoMPGData.DATA_FILE_CLEAN):
            logging.info('auto-mpg.clean.txt exists')

        Record = namedtuple('Record', 'mpg, cylinders, displacement, horsepower, weight, acceleration, model_year, '
                                      'origin, car_name')

        self.data = []
        with open(AutoMPGData.DATA_FILE_CLEAN, 'r') as f:
            reader = csv.reader(f, delimiter=' ', skipinitialspace=True)
            for row in reader:
                rec = Record(*[tok.strip() for tok in row])
                name_parts = rec.car_name.split()
                auto = AutoMPG(name_parts[0], " ".join(name_parts[1:]), rec.model_year, rec.mpg)
                self.data.append(auto)

    def _clean_data(self):
        """Reads original data file line by line"""

        ifname = AutoMPGData.DATA_FILE_ORIG
        ofname = AutoMPGData.DATA_FILE_CLEAN
        with open(ifname, 'r') as ifile:
            with open(ofname, 'w') as ofile:
                for line in ifile:
                    ofile.write(line.expandtabs())

    def sort_by_default(self):
        """Sorts the data list in place. The list will be sorted by make, model, year, and then mpg"""
        self.data.sort()
        logging.info('sorting AutoMPG objects by default')

    def sort_by_year(self):
        """The sorting happens by year, make, model, mpg"""
        self.data.sort(key=lambda x: (x.year, x.make, x.model, x.mpg))
        logging.info('sorting AutoMPG objects by year')

    def sort_by_mpg(self):
        """The sorting happens by mpg, make, model, year"""
        self.data.sort(key=lambda x: (x.mpg, x.make, x.model, x.year))
        logging.info('sorting AutoMPG objects by mpg')

    def _get_data(self):
        """Downloads the original data file from the UCI Machine Learning Repository and saves it in the local file as
           auto-mpg.data.txt."""

        logging.info('Getting auto-mpg.data.txt')
        r = requests.get('https://archive.ics.uci.edu/ml/machine-learning-databases/auto-mpg/auto-mpg.data')
        local_file = 'auto-mpg.data.txt'
        with open(local_file, 'wb') as file:
            file.write(r.content)

def main():
    # Get the root logger, set default to DEBUG
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # File Handler
    fh = logging.FileHandler('autompg2.log', 'w')
    fh.setLevel(logging.DEBUG)
    logger.addHandler(fh)

    # Stream Handler
    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)
    logger.addHandler(sh)

    # Application Code
    logging.debug('very detailed information')
    logging.info('tracing info')
    logging.warning('something bad might happen')
    logging.error('something bad happened')
    logging.critical('something really bad happened')

    logging.info("parsing auto-mpg.clean.txt into AutoMPG objects")
    # Command Line Parsing
    parser = argparse.ArgumentParser(description='Parse data from specified access_log')

    # Required Argument
    parser.add_argument('command', metavar='<command>', type=str, help='Command to execute')

    # Optional Arguments
    parser.add_argument('-s', '--sort', metavar='<sort order>', type=str, dest='SORT',
                        help='sort order by year, mpg or default', choices=['year', 'mpg', 'default'])

    if len(sys.argv) <= 1:
        sys.argv.append('--help')

    if sys.argv[3] == 'default':
        AutoMPGObject = AutoMPGData()
        AutoMPGObject.sort_by_default()
        for auto in AutoMPGObject:
            print(auto)

    if sys.argv[3] == 'year':
        AutoMPGObject = AutoMPGData()
        AutoMPGObject.sort_by_year()
        for auto in AutoMPGObject:
            print(auto)

    if sys.argv[3] == 'mpg':
        AutoMPGObject = AutoMPGData()
        AutoMPGObject.sort_by_mpg()
        for auto in AutoMPGObject:
            print(auto)

if __name__ == "__main__":
    main()
